import UIKit

// MARK: Async await

//func fetchWeatherHistory(completion: @escaping ([Double]) -> Void) {
//    // Complex networking code here; we'll just send back 100,000 random temperatures
//    DispatchQueue.global().async {
//        let results = (1...100_000).map { _ in Double.random(in: -10...30) }
//        completion(results)
//    }
//}
//
//func calculateAverageTemperature(for records: [Double], completion: @escaping (Double) -> Void) {
//    // Sum our array then divide by the array size
//    DispatchQueue.global().async {
//        let total = records.reduce(0, +)
//        let average = total / Double(records.count)
//        completion(average)
//    }
//}
//
//func upload(result: Double, completion: @escaping (String) -> Void) {
//    // More complex networking code; we'll just send back "OK"
//    DispatchQueue.global().async {
//        completion("OK")
//    }
//}
//
//fetchWeatherHistory { records in
//    calculateAverageTemperature(for: records) { average in
//        upload(result: average) { response in
//            print("Server response: \(response)")
//        }
//    }
//}

/* 
 Hopefully you can see the problems with this approach:
 
 It’s possible for those functions to call their completion handler more than once, or forget to call it entirely.
 The parameter syntax @escaping (String) -> Void can be hard to read.
 At the call site we end up with a so-called pyramid of doom, with code increasingly indented for each completion handler.
 Until Swift 5.0 added the Result type, it was harder to send back errors with completion handlers.
 */

//func fetchWeatherHistory() async -> [Double] {
//  (1...100_000).map { _ in Double.random(in: -10...30) }
//}
//
//func calculateAverageTemperature(for records: [Double]) async -> Double {
//    let total = records.reduce(0, +)
//    let average = total / Double(records.count)
//    return average
//}
//
//func upload(result: Double) async -> String {
//    "OK"
//}
//
//func processWeather() async {
//  let records = await fetchWeatherHistory()
//  let average = await calculateAverageTemperature(for: records)
//  let response = await upload(result: average)
//  print("Server response: \(response)")
//}

/* The addition of async/await fits perfectly alongside try/catch, meaning that async functions and initializers can throw errors if needed. The only proviso here is that Swift enforces a particular order for the keywords, and that order is reversed between call site and function.
 */

// MARK: Async await with try catch

enum UserError: Error {
    case invalidCount, dataTooLong
}

func fetchUsers(count: Int) async throws -> [String] {
    if count > 3 {
        // Don't attempt to fetch too many users
        throw UserError.invalidCount
    }

    // Complex networking code here; we'll just send back up to `count` users
    return Array(["Antoni", "Karamo", "Tan"].prefix(count))
}

func save(users: [String]) async throws -> String {
    let savedUsers = users.joined(separator: ",")

    if savedUsers.count > 32 {
        throw UserError.dataTooLong
    } else {
        // Actual saving code would go here
        return "Saved \(savedUsers)!"
    }
}

func updateUsers() async {
  do {
    async let users = /*try await*/ fetchUsers(count: 3)
    async let users1 = /*try await*/ fetchUsers(count: 2)
//    let result = try await save(users: users)
    
//    let allUsers = [users, users1]
    
    try await print([users, users1])
  } catch {
    print("Oops!")
  }
}

/* Important: Making a function asynchronous doesn’t mean it magically runs concurrently with other code, which means unless you specify otherwise calling multiple async functions will still run them sequentially.
 */

// MARK: Effectful read-only properties
enum FileError: Error {
  case missing, unreadable
}

struct BundleFile {
  let filename: String
  
  var contents: String {
    get async throws {
      guard let url = Bundle.main.url(forResource: filename, withExtension: nil) else {
        throw FileError.missing
      }
      
      do {
        return try String(contentsOf: url)
      } catch {
        throw FileError.unreadable
      }
    }
  }
}

func printHighScores() async throws {
  let file = BundleFile(filename: "highscores")
  try await print(file.contents)
}


// MARK: Async sequences

struct DoubleGenerator: AsyncSequence {
    typealias Element = Int

    struct AsyncIterator: AsyncIteratorProtocol {
        var current = 1

        mutating func next() async -> Int? {
//          fetchUsers(for userID: 1)
            defer { current &*= 2 }

            if current < 0 {
                return nil
            } else {
                return current
            }
        }
    }

    func makeAsyncIterator() -> AsyncIterator {
        AsyncIterator()
    }
}

func printAllDoubles() async {
    for await number in DoubleGenerator() {
        print(number)
    }
}

/*
 The AsyncSequence protocol also provides default implementations of a variety of common methods, such as map(), compactMap(), allSatisfy(), and more. For example, we could check whether our generator outputs a specific number like this:
 */

func containsExactNumber() async {
    let doubles = DoubleGenerator()
    let match = await doubles.contains(16777216)
    print(match)
}


// MARK: Actors
class RiskyCollector {
    var deck: Set<String>

    init(deck: Set<String>) {
        self.deck = deck
    }

    func send(card selected: String, to person: RiskyCollector) -> Bool {
        guard deck.contains(selected) else { return false }

        deck.remove(selected)
        person.transfer(card: selected)
        return true
    }

    func transfer(card: String) {
        deck.insert(card)
    }
}

actor SafeCollector {
    var deck: Set<String>

    init(deck: Set<String>) {
        self.deck = deck
    }

    func send(card selected: String, to person: SafeCollector) async -> Bool {
        guard deck.contains(selected) else { return false }

        deck.remove(selected)
        await person.transfer(card: selected)
        return true
    }

    func transfer(card: String) {
        deck.insert(card)
    }
}

/*
 Actors and classes have some similarities:
 
 - Both are reference types, so they can be used for shared state.
 - They can have methods, properties, initializers, and subscripts.
 - They can conform to protocols and be generic.
 - Any properties and methods that are static behave the same in both types, because they have no concept of self and therefore don’t get isolated.
 
 Beyond actor isolation, there are two other important differences between actors and classes:
 - Actors do not currently support inheritance, which makes their initializers much simpler – there is no need for convenience initializers, overriding, the final keyword, and more. This might change in the future.
 - All actors implicitly conform to a new Actor protocol; no other concrete type can use this. This allows you to restrict other parts of your code so it can work only with actors.*/


// MARK: Global actors
class OldDataController {
    func save() -> Bool {
        guard Thread.isMainThread else {
            return false
        }

        print("Saving data…")
        return true
    }
}

/* That works, but with @MainActor we can guarantee that save() is always called on the main thread as if we specifically ran it using DispatchQueue.main:
 */

class NewDataController {
    @MainActor func save() {
        print("Saving data…")
    }
}

let newDC = NewDataController()
Task {
  await newDC.save()
}

/* @MainActor is a global actor wrapper around the underlying MainActor struct, which is helpful because it has a static run() method that lets us schedule work to be run. This will execute your code on the main thread, optionally sending back a result.
 */

//@globalActor
//actor MyMainActor {
//  static var shared = MainActor()
//  
//  func run() {
//    
//  }
//}
